#!/bin/bash
#
#
# Created by Jeremi Albrizio 10/31/2012
# This file should never be placed in /
#
# Set the Servername and Date veriable
#
SERVERNAME=`hostname`
#TODAYSDATE=$(date +"$m%d%y-%H%M")
TODAYSDATE=`date`

sitebase='/var/www/vhosts/FastActionLoans.com/httpdocs/system'
ipadd='web5'
depbase=/var/deploy/leadsystem.git
PATH=`pwd`:$PATH

#
siteuser=`sudo ssh gituser@$ipadd ls -l $sitebase/../ | grep cgi-bin | awk '{print $3}'`
export siteuser
echo "sites user is: $siteuser"
echo "Executing Gitpush.sh"
sudo ssh gituser@$ipadd "cd $sitebase/;sudo chmod -R 775 $sitebase;sudo git reset --hard HEAD;sudo git pull;sleep 5;sudo chmod -R 775 $sitebase;sudo chown -R $siteuser.psaserv $sitebase;"
echo "done"

