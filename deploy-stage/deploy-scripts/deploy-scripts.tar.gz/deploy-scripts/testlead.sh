#!/bin/bash
#
#
# Created by Jeremi Albrizio 11/7/2012
# This file should never be placed in /
#
# 
#
LIVLOC="/var/www/vhosts/LightSpeedLoansUSA.com/httpdocs"
SITEADD=`grep "$LIVLOC" /var/deploy/deploy-scripts/web5.txt | wc -l`
if [ $SITEADD -gt 0 ]
  then
    echo "there is already and entry in /var/deploy/deploy-scripts/$PRODIP.txt."
    echo "there are $SITEADD entries"
    echo "Skipping the /var/deploy/deploy-scripts/$PRODIP.txt update"
  else
    echo "there are $SITEADD entries"
    echo "No /var/deploy/deploy-scripts/$PRODIP.txt entries found."
    echo "adding the /var/deploy/deploy-scripts/$PRODIP.txt entry"
    echo "$LIVLOC" | cat >> /var/deploy/deploy-scripts/$PRODIP.txt
fi
echo ""

echo "
chown -R root.dev /var/deploy/*.git > /dev/null
chmod -R g+swX /var/deploy/*.git > /dev/null
chown -R root.dev /var/deploy/deploy-scripts > /dev/null
chmod -R 770 /var/deploy/deploy-scripts > /dev/null

