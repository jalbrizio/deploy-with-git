#!/bin/bash
#
#
# Created by Jeremi Albrizio 10/31/2012
# This file should never be placed in /
#
# Set the Servername and Date veriable
#
SERVERNAME=`hostname`
#TODAYSDATE=$(date +"$m%d%y-%H%M")
TODAYSDATE=`date`

sitebase='/var/www/vhosts/FastActionLoans.com/httpdocs/system'
ipadd='web5'
depbase=/var/deploy/leadsystem.git

siteuser=`ls -l $sitebase/../ | grep cgi-bin | awk '{print $3}'`

cd $sitebase
chmod -R 775 $sitebase
chmod -R 775 $sitebase/wp-content/uploads
chown -R $siteuser.psaserv $sitebase
git reset --hard HEAD
git pull
sleep 5
chmod -R 775 $sitebase
chmod -R 775 $sitebase/wp-content/uploads
chown -R $siteuser.psaserv $sitebase


