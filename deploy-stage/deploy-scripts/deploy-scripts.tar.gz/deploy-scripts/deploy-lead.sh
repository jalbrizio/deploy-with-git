#!/bin/bash
#
#
# Created by Jeremi Albrizio 11/7/2012
# This file should never be placed in /
#
# 
#
REPOBASE="/var/git"
DEPLOYBASE="/var/deploy"
SERVERNAME=`hostname`
LOCALIP=`wget -qO- ifconfig.me/ip`
DSCRIPTS="/var/deploy/deploy-scripts"
#TODAYSDATE=$(date +"$m%d%y-%H%M")
TODAYSDATE=`date`
SSHUSER=gituser
DEPLRP="/var/deploy/leadsystem.git"
REPO="/var/git/leadsystem.git"
GDOMAIN=`echo $REPO | sed s/\.git//g`
echo "The location of the repo is /var/git/leadsystem.git"
echo ""

#echo ""
echo "What is the location of the live site data?"
echo "example /var/www/vhosts/domain.com/httpdocs/system"
read LIVLOC
echo ""

echo "What is the  production server you are using?"
echo "example whould be: web3 web4 web5"
read PRODIP
echo ""
sleep 3

SITEADD=`grep $LIVLOC /var/deploy/deploy-scripts/$PRODIP.txt | wc -l`

echo "Building deployment repo"
echo "User: $SSHUSER" 
echo "Original repo: $REPO"
echo "Deployment repo:  $REPO" 
echo "Location on Production: $LIVLOC" 
echo "production server IP: $PRODIP"
sleep 6
echo ""

echo "sitebase='$LIVLOC'" > $DSCRIPTS/mid.txt
echo "ipadd='$PRODIP'" >> $DSCRIPTS/mid.txt
echo "depbase=$DEPLRP" >> $DSCRIPTS/mid.txt


cat $DSCRIPTS/head.txt $DSCRIPTS/mid.txt $DSCRIPTS/gitpull.sh-copy > /var/deploy/deploy-scripts/gitpull.sh
cat $DSCRIPTS/head.txt $DSCRIPTS/mid.txt $DSCRIPTS/Gitpush.sh-copy > /var/deploy/deploy-scripts/Gitpush.sh

mkdir -p /var/deploy/deploy-scripts/
touch /var/deploy/deploy-scripts/$PRODIP.txt

if [ $SITEADD -gt 0 ]
  then
    echo "there is already and entry in /var/deploy/deploy-scripts/$PRODIP.txt."
    echo "Skipping the /var/deploy/deploy-scripts/$PRODIP.txt update"
  else
    echo "No /var/deploy/deploy-scripts/$PRODIP.txt entries found."
    echo "adding the /var/deploy/deploy-scripts/$PRODIP.txt entry"
    echo "$LIVLOC" | cat >> /var/deploy/deploy-scripts/$PRODIP.txt
fi
sleep 2
echo ""
echo backing up the site first.

ssh gituser@web5 sudo mkdir -p $LIVLOC --mode=777;
SITEUSER=`sudo ssh gituser@$PRODIP ls -l $LIVLOC/../../ | grep cgi-bin | awk '{print $3}'`
export SITEUSER
echo "Site user is: $SITEUSER"
ssh gituser@$PRODIP "cd $LIVLOC; cd ../../; sudo tar -czf $GDOMAIN.tar.gz ./httpdocs/system;"
ssh gituser@$PRODIP "cd $LIVLOC;cd ..;sudo rm -Rf system;sudo git clone ssh://gituser@$LOCALIP$DEPLRP ./system/;sudo chmod -R 775 $LIVLOC;sudo chown -R $SITEUSER $LIVLOC;sudo chgrp -R psaserv $LIVLOC;"
cd /var/deploy/deploy-scripts/
scp gitpull.sh gituser@$PRODIP:$LIVLOC/gitpull.sh
scp gitignore-addition gituser@$PRODIP:$LIVLOC/gitignore-addition
ssh gituser@$PRODIP "cd $LIVLOC;cat gitignore-addition >> .gitignore;
echo ""
echo "done building deployment"
echo""
echo "Make sure the Gitpush.sh and gitpull.sh files get placed in your developement repo"
echo ""
echo "Then go to the production server and do a git clone ssh://gituser@$LOCALIP$REPO"
echo ""
echo "As long as the sshkeys are on place you will be able to push to production when ever you do a commit from your deployment repo."
echo ""
echo "if you have more files you want to ignore then add them to the gitignore-additionfile so when you build your repo it will be added."
echo ""
echo "Have a nice day."
echo "
chown -R root.dev /var/deploy/*.git
chgrp -R dev /var/git/*.git
chmod -R g+swX /var/deploy/*.git
chown -R root.dev /var/deploy/deploy-scripts
chmod -R 770 /var/deploy/deploy-scripts
find /var/deploy -name hooks -exec chmod -R 770 {} \;
exit
