#!/bin/bash
#
#
# Created by Jeremi Albrizio 11/7/2012
# This file should never be placed in /
#
# 
#
REPOBASE="/var/git"
DEPLOYBASE="/var/deploy"
SERVERNAME=`hostname`
LOCALIP=`wget -qO- ifconfig.me/ip`
DSCRIPTS="/var/deploy/deploy-scripts"
#TODAYSDATE=$(date +"$m%d%y-%H%M")
TODAYSDATE=`date`
#echo "What is the user you are using?"
#read SSHUSER
SSHUSER=gituser
#echo ""
echo "what is the location of the repo?"
echo "example domain_com.git"
read REPO
echo ""
#echo "what is the location you want the deploy repo in?"
#echo "example /var/deploy/domain_com"
#read DEPLRP
#echo ""
echo "What is the location of the live site data?"
echo "example /var/www/vhosts/domain.com/httpdocs"
read LIVLOC
echo ""
echo "What is the ip address of the production server you are using?"
echo "68.2.16.30"
read PRODIP
echo ""
sleep 3
echo "Building deployment repo"
echo "User: $SSHUSER" 
echo "Original repo: $REPOBASE/$REPO"
echo "Deployment repo: $DEPLOYBASE/$REPO" 
echo "Location on Production: $LIVLOC" 
echo "production server IP: $PRODIP"
sleep 6
echo ""
GDOMAIN=`echo $REPO | sed s/\.git//g |sed s/\_/\./g`
#
mkdir -p $DEPLOYBASE/$REPO
cd $DEPLOYBASE/$REPO
git init --bare

echo "sitebase='$LIVLOC'" > $DSCRIPTS/mid.txt
echo "ipadd='$PRODIP'" >> $DSCRIPTS/mid.txt
echo "depbase=$DEPLOYBASE/$REPO" >> $DSCRIPTS/mid.txt

git clone $REPOBASE/$REPO $DEPLOYBASE/paging
cat $DSCRIPTS/htaccess-addition | sed s/xxxxxxxxxx/$GDOMAIN >> $DEPLOYBASE/paging/.htaccess
cat $DSCRIPTS/gitignore-addition >> $DEPLOYBASE/paging/.gitignore
cd $DEPLOYBASE/paging/ 
git add -A
git commit -m "initial deploy repo setup" -a
git remote add deploy $DEPLOYBASE/$REPO
git push deploy master
git push
mkdir -p $DEPLOYBASE/$REPO/hooks/
touch $DEPLOYBASE/$REPO/hooks/Gitpush.sh
touch $DEPLOYBASE/$REPO/hooks/gitpull.sh
cat $DSCRIPTS/head.txt $DSCRIPTS/mid.txt $DSCRIPTS/gitpull.sh-copy > $DEPLOYBASE/$REPO/hooks/gitpull.sh
cat $DSCRIPTS/head.txt $DSCRIPTS/mid.txt $DSCRIPTS/Gitpush.sh-copy > $DEPLOYBASE/$REPO/hooks/Gitpush.sh

cp $DSCRIPTS/post-commit $DEPLOYBASE/$REPO/hooks
#cat $DSCRIPTS/post-receive | sed s/xxxxxxxxxx/$DEPLOYBASE\\/$REPO/hooks/g > $DEPLOYBASE/$REPO/hooks/post-receive
cat /var/deploy/deploy-scripts/post-receive | sed s/xxxxxxxxxx/\\/var\\/deploy\\/$REPO\\/hooks/g > $DEPLOYBASE/$REPO/hooks/post-receive
sleep 2

echo backing up the site first.
ssh gituser@$PRODIP "sudo mkdir -p $LIVLOC --mode=777;sudo chmod -R 777 $LIVLOC;ls $LIVLOC/../ | grep httpdocs"
siteuser=`sudo ssh gituser@$PRODIP ls -l $LIVLOC/../ | grep cgi-bin | awk '{print $3}'`
export siteuser
echo "sites user is: $siteuser"
ssh gituser@$PRODIP "sudo mkdir -p $LIVLOC --mode=777;sudo chmod -R 777 $LIVLOC;cd $LIVLOC; cd ../; sudo tar -czf $GDOMAIN.tar.gz ./httpdocs;"
ssh gituser@$PRODIP "cd $LIVLOC;cd ../;sudo rm -Rf httpdocs;"

chown -R root.dev /var/deploy/*.git
chmod -R g+swX /var/deploy/*.git
chown -R root.dev /var/deploy/deploy-scripts
chmod -R 770 /var/deploy/deploy-scripts
find /var/deploy -name hooks -exec chmod -R 770 {} \;
/usr/bin/remove-paging.sh

ssh gituser@$PRODIP "sudo mkdir -p $LIVLOC --mode=777;sudo chmod -R 777 $LIVLOC/;"
ssh gituser@$PRODIP "sudo mkdir -p $LIVLOC --mode=777;sudo chmod -R 777 $LIVLOC/;"
ssh gituser@$PRODIP "cd $LIVLOC;cd ../;sudo git clone ssh://gituser@$LOCALIP$DEPLOYBASE/$REPO ./httpdocs/;sudo chmod -R 775 $LIVLOC;sudo "chown -R $siteuser.psaserv $LIVLOC";"
cd $DEPLOYBASE/$REPO/hooks/
scp gitpull.sh gituser@$PRODIP:$LIVLOC/gitpull.sh
scp gitignore-addition gituser@$PRODIP:$LIVLOC/gitignore-addition
ssh gituser@$PRODIP "cd $LIVLOC;cat gitignore-addition >> .gitignore;
echo " "
rm -Rf $DEPLOYBASE/paging/
echo "done building deployment"
echo" "
echo "Make sure the Gitpush.sh and gitpull.sh files get placed in your developement repo"
echo " "
echo "Then go to the production server and do a git clone ssh://gituser@$LOCALIP$DEPLOYBASE/$REPO"
echo " "
echo "As long as the sshkeys are on place you will be able to push to production when ever you do a commit from your deployment repo."
echo " "
echo "if you have more files you want to ignore then add them to the gitignore-additionfile so when you build your repo it will be added."
echo " "
chown -R root.dev /var/deploy/*.git
chgrp -R dev /var/git/*.git
chmod -R g+swX /var/deploy/*.git
chown -R root.dev /var/deploy/deploy-scripts
chmod -R 770 /var/deploy/deploy-scripts
find /var/deploy -name hooks -exec chmod -R 770 {} \;
/usr/bin/remove-paging.sh
