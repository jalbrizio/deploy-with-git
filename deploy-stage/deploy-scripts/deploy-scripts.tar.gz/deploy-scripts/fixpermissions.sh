chown -R root.dev /var/deploy/*.git 
chmod -R g+swX /var/deploy/*.git 
chown -R root.dev /var/deploy/deploy-scripts
chmod -R 770 /var/deploy/deploy-scripts 
find /var/deploy -name hooks -exec chmod -R 770 {} \;
/usr/bin/remove-paging.sh
