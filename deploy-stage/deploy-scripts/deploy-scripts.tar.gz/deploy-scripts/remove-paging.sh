rm -Rf /var/deploy/paging
