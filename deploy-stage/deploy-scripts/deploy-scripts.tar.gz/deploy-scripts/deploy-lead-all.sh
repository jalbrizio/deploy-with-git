find /var/deploy/ -name Gitpush.sh | grep "/deploy/" | xargs -i echo  "running {}"\;
